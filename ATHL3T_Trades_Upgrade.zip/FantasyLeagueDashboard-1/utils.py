import pandas as pd
import os

def load_data():
    """
    Load all data from CSV files
    """
    players = pd.read_csv("data/data_players.csv")
    funds = pd.read_csv("data/data_team_funds.csv")
    users = pd.read_csv("data/data_users.csv")
    holdings = pd.read_csv("data/data_holdings.csv")
    
    # Clean and convert data types as needed
    players["Current Price"] = pd.to_numeric(players["Current Price"])
    players["Initial Price"] = pd.to_numeric(players["Initial Price"])
    funds["Fund Price"] = pd.to_numeric(funds["Fund Price"])
    users["Wallet Balance"] = pd.to_numeric(users["Wallet Balance"])
    
    # Ensure holdings has a quantity column as numeric
    if "Quantity" in holdings.columns:
        holdings["Quantity"] = pd.to_numeric(holdings["Quantity"])
    
    return players, funds, users, holdings

def save_data(players, funds, users, holdings):
    """
    Save all data to CSV files
    """
    players.to_csv("data/data_players.csv", index=False)
    funds.to_csv("data/data_team_funds.csv", index=False)
    users.to_csv("data/data_users.csv", index=False)
    holdings.to_csv("data/data_holdings.csv", index=False)

def execute_transaction(user_id, asset_type, asset_name, transaction_type, price, users, holdings):
    """
    Execute a buy or sell transaction
    
    Parameters:
    - user_id: ID of the user
    - asset_type: Type of asset (Player or Team Fund)
    - asset_name: Name of the asset
    - transaction_type: buy or sell
    - price: Current price of the asset
    - users: Users dataframe
    - holdings: Holdings dataframe
    
    Returns:
    - success: Boolean indicating if transaction was successful
    - message: Message about the transaction
    - users: Updated users dataframe
    - holdings: Updated holdings dataframe
    """
    # Get user's wallet balance
    user_idx = users[users["User ID"] == user_id].index[0]
    wallet_balance = users.loc[user_idx, "Wallet Balance"]
    
    if transaction_type == "buy":
        # Check if user has enough funds
        if wallet_balance < price:
            return False, f"Insufficient funds. Need ${price:.2f}, but you have ${wallet_balance:.2f}", users, holdings
        
        # Deduct funds from wallet
        users.loc[user_idx, "Wallet Balance"] = wallet_balance - price
        
        # Update holdings - check if user already has this asset
        existing_holding = holdings[(holdings["User ID"] == user_id) & 
                                   (holdings["Type"] == asset_type) & 
                                   (holdings["Asset Name"] == asset_name)]
        
        if not existing_holding.empty:
            # Update existing holding
            holding_idx = existing_holding.index[0]
            holdings.loc[holding_idx, "Quantity"] += 1
        else:
            # Create new holding
            new_holding = pd.DataFrame({
                "User ID": [user_id],
                "Type": [asset_type],
                "Asset Name": [asset_name],
                "Quantity": [1]
            })
            holdings = pd.concat([holdings, new_holding], ignore_index=True)
        
        return True, f"Successfully bought 1 share of {asset_name} for ${price:.2f}", users, holdings
    
    elif transaction_type == "sell":
        # Check if user has the asset
        existing_holding = holdings[(holdings["User ID"] == user_id) & 
                                   (holdings["Type"] == asset_type) & 
                                   (holdings["Asset Name"] == asset_name)]
        
        if existing_holding.empty or existing_holding.iloc[0]["Quantity"] < 1:
            return False, f"You don't own any shares of {asset_name} to sell", users, holdings
        
        # Add funds to wallet
        users.loc[user_idx, "Wallet Balance"] = wallet_balance + price
        
        # Update holdings
        holding_idx = existing_holding.index[0]
        current_quantity = holdings.loc[holding_idx, "Quantity"]
        
        if current_quantity == 1:
            # Remove the holding completely
            holdings = holdings.drop(holding_idx)
        else:
            # Reduce quantity
            holdings.loc[holding_idx, "Quantity"] -= 1
        
        return True, f"Successfully sold 1 share of {asset_name} for ${price:.2f}", users, holdings
    
    return False, "Invalid transaction type", users, holdings
