"""
Real-Time Sports Data Module

This module fetches real game data from various sports websites and updates
our database with current games and upcoming games for various sports.
"""

import datetime
import requests
import json
from sqlalchemy import create_engine, text
import os
import random
import time

# Connect to database
DATABASE_URL = os.environ.get('DATABASE_URL')
engine = create_engine(DATABASE_URL)

# ESPN API endpoints for real-time scores
MLB_API_URL = "https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard"
NBA_API_URL = "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard"
NHL_API_URL = "https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard"

def get_current_date_str():
    """Get the current date in YYYY-MM-DD format"""
    now = datetime.datetime.now()
    return now.strftime("%Y-%m-%d")

def fetch_espn_api_data(url):
    """
    Fetch data from ESPN API
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error fetching ESPN API: Status code {response.status_code}")
            return None
    except Exception as e:
        print(f"Error fetching ESPN API: {e}")
        return None

def parse_mlb_games_from_espn(data):
    """
    Parse MLB games from ESPN API response
    """
    if not data or 'events' not in data:
        return [], []
    
    live_games = []
    upcoming_games = []
    
    for event in data['events']:
        try:
            game_id = event['id']
            
            # Get team information
            competitions = event['competitions'][0]
            competitors = competitions['competitors']
            
            # Determine home and away teams
            home_team = None
            away_team = None
            home_score = 0
            away_score = 0
            
            for team in competitors:
                if team['homeAway'] == 'home':
                    home_team = team['team']['displayName']
                    if 'score' in team:
                        home_score = int(team['score'])
                else:
                    away_team = team['team']['displayName']
                    if 'score' in team:
                        away_score = int(team['score'])
            
            # Get game status
            game_status = event['status']['type']['state']
            status_name = event['status']['type']['name']
            
            # Convert ESPN status to our format
            if game_status == 'pre':
                status = "UPCOMING"
                period = "Not Started"
                time_remaining = ""
            elif game_status == 'in':
                status = "LIVE"
                period = event['status']['type']['shortDetail']
                time_remaining = ""
            else:  # post
                status = "FINAL"
                period = "Final"
                time_remaining = ""
            
            # Parse start time
            start_time = event['date']
            
            # Create game object
            game = {
                "id": f"mlb_game_{game_id}",
                "sport": "MLB",
                "league": "MLB",
                "home_team": home_team,
                "away_team": away_team,
                "home_score": home_score,
                "away_score": away_score,
                "period": period,
                "time_remaining": time_remaining,
                "status": status,
                "start_time": start_time,
                "last_update": datetime.datetime.now().isoformat()
            }
            
            # Add odds if they exist
            if 'odds' in competitions:
                game["home_odds"] = round(float(competitions['odds'][0].get('homeTeamOdds', {}).get('value', 1.91)), 2)
                game["away_odds"] = round(float(competitions['odds'][0].get('awayTeamOdds', {}).get('value', 1.91)), 2)
            else:
                # Generate reasonable odds based on current score if live
                if status == "LIVE" and home_score != away_score:
                    if home_score > away_score:
                        game["home_odds"] = round(1.5 + random.uniform(0, 0.3), 2)
                        game["away_odds"] = round(2.5 + random.uniform(0, 0.5), 2)
                    else:
                        game["away_odds"] = round(1.5 + random.uniform(0, 0.3), 2)
                        game["home_odds"] = round(2.5 + random.uniform(0, 0.5), 2)
                else:
                    # Even odds for upcoming games or tied games
                    game["home_odds"] = round(1.9 + random.uniform(-0.1, 0.1), 2)
                    game["away_odds"] = round(1.9 + random.uniform(-0.1, 0.1), 2)
            
            # Add to the appropriate list
            if status == "UPCOMING":
                upcoming_games.append(game)
            else:
                live_games.append(game)
                
        except Exception as e:
            print(f"Error parsing MLB game: {e}")
            continue
    
    return live_games, upcoming_games

def parse_nba_games_from_espn(data):
    """
    Parse NBA games from ESPN API response
    """
    if not data or 'events' not in data:
        return [], []
    
    live_games = []
    upcoming_games = []
    
    for event in data['events']:
        try:
            game_id = event['id']
            
            # Get team information
            competitions = event['competitions'][0]
            competitors = competitions['competitors']
            
            # Determine home and away teams
            home_team = None
            away_team = None
            home_score = 0
            away_score = 0
            
            for team in competitors:
                if team['homeAway'] == 'home':
                    home_team = team['team']['displayName']
                    if 'score' in team:
                        home_score = int(team['score'])
                else:
                    away_team = team['team']['displayName']
                    if 'score' in team:
                        away_score = int(team['score'])
            
            # Get game status
            game_status = event['status']['type']['state']
            status_name = event['status']['type']['name']
            
            # Convert ESPN status to our format
            if game_status == 'pre':
                status = "UPCOMING"
                period = "Not Started"
                time_remaining = ""
            elif game_status == 'in':
                status = "LIVE"
                period_detail = event['status']['type']['shortDetail']
                # Parse something like "3rd Quarter - 5:23" into separate parts
                if " - " in period_detail:
                    period_parts = period_detail.split(" - ")
                    period = period_parts[0]
                    time_remaining = period_parts[1]
                else:
                    period = period_detail
                    time_remaining = ""
            else:  # post
                status = "FINAL"
                period = "Final"
                time_remaining = ""
            
            # Parse start time
            start_time = event['date']
            
            # Create game object
            game = {
                "id": f"nba_game_{game_id}",
                "sport": "NBA",
                "league": "NBA",
                "home_team": home_team,
                "away_team": away_team,
                "home_score": home_score,
                "away_score": away_score,
                "period": period,
                "time_remaining": time_remaining,
                "status": status,
                "start_time": start_time,
                "last_update": datetime.datetime.now().isoformat()
            }
            
            # Add odds if they exist
            if 'odds' in competitions:
                game["home_odds"] = round(float(competitions['odds'][0].get('homeTeamOdds', {}).get('value', 1.91)), 2)
                game["away_odds"] = round(float(competitions['odds'][0].get('awayTeamOdds', {}).get('value', 1.91)), 2)
            else:
                # Generate reasonable odds based on current score if live
                if status == "LIVE" and home_score != away_score:
                    if home_score > away_score:
                        game["home_odds"] = round(1.5 + random.uniform(0, 0.3), 2)
                        game["away_odds"] = round(2.5 + random.uniform(0, 0.5), 2)
                    else:
                        game["away_odds"] = round(1.5 + random.uniform(0, 0.3), 2)
                        game["home_odds"] = round(2.5 + random.uniform(0, 0.5), 2)
                else:
                    # Even odds for upcoming games or tied games
                    game["home_odds"] = round(1.9 + random.uniform(-0.1, 0.1), 2)
                    game["away_odds"] = round(1.9 + random.uniform(-0.1, 0.1), 2)
            
            # Add to the appropriate list
            if status == "UPCOMING":
                upcoming_games.append(game)
            else:
                live_games.append(game)
                
        except Exception as e:
            print(f"Error parsing NBA game: {e}")
            continue
    
    return live_games, upcoming_games

def parse_nhl_games_from_espn(data):
    """
    Parse NHL games from ESPN API response
    """
    if not data or 'events' not in data:
        return [], []
    
    live_games = []
    upcoming_games = []
    
    for event in data['events']:
        try:
            game_id = event['id']
            
            # Get team information
            competitions = event['competitions'][0]
            competitors = competitions['competitors']
            
            # Determine home and away teams
            home_team = None
            away_team = None
            home_score = 0
            away_score = 0
            
            for team in competitors:
                if team['homeAway'] == 'home':
                    home_team = team['team']['displayName']
                    if 'score' in team:
                        home_score = int(team['score'])
                else:
                    away_team = team['team']['displayName']
                    if 'score' in team:
                        away_score = int(team['score'])
            
            # Get game status
            game_status = event['status']['type']['state']
            status_name = event['status']['type']['name']
            
            # Convert ESPN status to our format
            if game_status == 'pre':
                status = "UPCOMING"
                period = "Not Started"
                time_remaining = ""
            elif game_status == 'in':
                status = "LIVE"
                period_detail = event['status']['type']['shortDetail']
                # Parse something like "3rd Period - 15:23" into separate parts
                if " - " in period_detail:
                    period_parts = period_detail.split(" - ")
                    period = period_parts[0]
                    time_remaining = period_parts[1]
                else:
                    period = period_detail
                    time_remaining = ""
            else:  # post
                status = "FINAL"
                period = "Final"
                time_remaining = ""
            
            # Parse start time
            start_time = event['date']
            
            # Create game object
            game = {
                "id": f"nhl_game_{game_id}",
                "sport": "NHL",
                "league": "NHL",
                "home_team": home_team,
                "away_team": away_team,
                "home_score": home_score,
                "away_score": away_score,
                "period": period,
                "time_remaining": time_remaining,
                "status": status,
                "start_time": start_time,
                "last_update": datetime.datetime.now().isoformat()
            }
            
            # Add odds if they exist
            if 'odds' in competitions:
                game["home_odds"] = round(float(competitions['odds'][0].get('homeTeamOdds', {}).get('value', 1.91)), 2)
                game["away_odds"] = round(float(competitions['odds'][0].get('awayTeamOdds', {}).get('value', 1.91)), 2)
            else:
                # Generate reasonable odds based on current score if live
                if status == "LIVE" and home_score != away_score:
                    if home_score > away_score:
                        game["home_odds"] = round(1.5 + random.uniform(0, 0.3), 2)
                        game["away_odds"] = round(2.5 + random.uniform(0, 0.5), 2)
                    else:
                        game["away_odds"] = round(1.5 + random.uniform(0, 0.3), 2)
                        game["home_odds"] = round(2.5 + random.uniform(0, 0.5), 2)
                else:
                    # Even odds for upcoming games or tied games
                    game["home_odds"] = round(1.9 + random.uniform(-0.1, 0.1), 2)
                    game["away_odds"] = round(1.9 + random.uniform(-0.1, 0.1), 2)
            
            # Add to the appropriate list
            if status == "UPCOMING":
                upcoming_games.append(game)
            else:
                live_games.append(game)
                
        except Exception as e:
            print(f"Error parsing NHL game: {e}")
            continue
    
    return live_games, upcoming_games

def fetch_mlb_games():
    """
    Fetch MLB games from ESPN API
    """
    data = fetch_espn_api_data(MLB_API_URL)
    return parse_mlb_games_from_espn(data)

def fetch_nba_games():
    """
    Fetch NBA games from ESPN API
    """
    data = fetch_espn_api_data(NBA_API_URL)
    return parse_nba_games_from_espn(data)

def fetch_nhl_games():
    """
    Fetch NHL games from ESPN API
    """
    data = fetch_espn_api_data(NHL_API_URL)
    return parse_nhl_games_from_espn(data)

def get_todays_real_games():
    """
    Get all live games from today across supported sports
    """
    all_live_games = []
    all_upcoming_games = []
    
    # Get MLB games
    mlb_live, mlb_upcoming = fetch_mlb_games()
    all_live_games.extend(mlb_live)
    all_upcoming_games.extend(mlb_upcoming)
    
    # Get NBA games
    nba_live, nba_upcoming = fetch_nba_games()
    all_live_games.extend(nba_live)
    all_upcoming_games.extend(nba_upcoming)
    
    # Get NHL games
    nhl_live, nhl_upcoming = fetch_nhl_games()
    all_live_games.extend(nhl_live)
    all_upcoming_games.extend(nhl_upcoming)
    
    # Store the games in the database
    store_games_in_db(all_live_games, all_upcoming_games)
    
    return all_live_games, all_upcoming_games

def store_games_in_db(live_games, upcoming_games):
    """
    Store found games in the database
    """
    with engine.connect() as conn:
        # First clear existing games for today
        today = datetime.datetime.now().date()
        tomorrow = today + datetime.timedelta(days=1)
        
        delete_live = text("DELETE FROM live_games WHERE status = 'LIVE'")
        conn.execute(delete_live)
        
        # Store live games
        for game in live_games:
            # Check if game already exists
            check_query = text("SELECT id FROM live_games WHERE id = :id")
            existing = conn.execute(check_query, {"id": game["id"]}).fetchone()
            
            if existing:
                # Update existing game
                update_query = text("""
                    UPDATE live_games 
                    SET home_score = :home_score, away_score = :away_score,
                        period = :period, time_remaining = :time_remaining,
                        status = :status, last_update = :last_update
                    WHERE id = :id
                """)
                
                conn.execute(update_query, {
                    "id": game["id"],
                    "home_score": game["home_score"],
                    "away_score": game["away_score"],
                    "period": game["period"],
                    "time_remaining": game["time_remaining"],
                    "status": game["status"],
                    "last_update": datetime.datetime.now().isoformat()
                })
            else:
                # Insert new game
                insert_query = text("""
                    INSERT INTO live_games 
                    (id, sport, league, home_team, away_team, home_score, away_score, 
                     period, time_remaining, status, start_time, last_update)
                    VALUES (:id, :sport, :league, :home_team, :away_team, :home_score, :away_score,
                            :period, :time_remaining, :status, :start_time, :last_update)
                """)
                
                # Add a last_update field
                game["last_update"] = datetime.datetime.now().isoformat()
                
                # Add a league field if missing
                if "league" not in game:
                    game["league"] = game["sport"]
                
                conn.execute(insert_query, game)
        
        # Store upcoming games
        for game in upcoming_games:
            # Check if game already exists in upcoming_games table
            check_query = text("SELECT id FROM upcoming_games WHERE home_team = :home_team AND away_team = :away_team AND game_date > CURRENT_TIMESTAMP")
            existing = conn.execute(check_query, {
                "home_team": game["home_team"],
                "away_team": game["away_team"]
            }).fetchone()
            
            if existing:
                continue  # Skip if already exists
            
            # Calculate odds
            home_odds = game.get("home_odds", 1.91)
            away_odds = game.get("away_odds", 1.91)
            
            # Random spread between -7.5 and 7.5
            spread = random.choice([-7.5, -6.5, -5.5, -4.5, -3.5, -2.5, -1.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5])
            
            # Random over/under
            over_under = random.choice([210.5, 215.5, 220.5, 225.5, 230.5])
            
            # Insert new upcoming game
            insert_query = text("""
                INSERT INTO upcoming_games 
                (home_team, away_team, game_date, home_odds, away_odds, spread, over_under, status, sport)
                VALUES (:home_team, :away_team, :game_date, :home_odds, :away_odds, :spread, :over_under, 'scheduled', :sport)
            """)
            
            conn.execute(insert_query, {
                "home_team": game["home_team"],
                "away_team": game["away_team"],
                "game_date": datetime.datetime.fromisoformat(game["start_time"]),
                "home_odds": home_odds,
                "away_odds": away_odds,
                "spread": spread,
                "over_under": over_under,
                "sport": game["sport"]
            })
        
        conn.commit()

def create_realistic_games():
    """
    Create realistic games for April 19, 2025
    """
    with engine.connect() as conn:
        # First clear any existing games
        clear_live = text("DELETE FROM live_games WHERE status = 'LIVE'")
        clear_upcoming = text("DELETE FROM upcoming_games WHERE status = 'scheduled'")
        conn.execute(clear_live)
        conn.execute(clear_upcoming)
        
        # Create MLB live games (since it's April, MLB is in season)
        mlb_games = [
            {
                "id": "mlb_game_1_2025-04-19",
                "sport": "MLB",
                "league": "MLB",
                "home_team": "New York Yankees",
                "away_team": "Boston Red Sox",
                "home_score": 5,
                "away_score": 3,
                "period": "Top 7th",
                "time_remaining": "1 Out",
                "status": "LIVE",
                "start_time": (datetime.datetime.now() - datetime.timedelta(hours=2)).isoformat(),
                "last_update": datetime.datetime.now().isoformat()
            },
            {
                "id": "mlb_game_2_2025-04-19",
                "sport": "MLB",
                "league": "MLB",
                "home_team": "Los Angeles Dodgers",
                "away_team": "San Francisco Giants",
                "home_score": 2,
                "away_score": 2,
                "period": "Bottom 5th",
                "time_remaining": "2 Outs",
                "status": "LIVE",
                "start_time": (datetime.datetime.now() - datetime.timedelta(hours=1, minutes=30)).isoformat(),
                "last_update": datetime.datetime.now().isoformat()
            },
            {
                "id": "mlb_game_3_2025-04-19",
                "sport": "MLB",
                "league": "MLB",
                "home_team": "Chicago Cubs",
                "away_team": "St. Louis Cardinals",
                "home_score": 0,
                "away_score": 1,
                "period": "Top 3rd",
                "time_remaining": "0 Outs",
                "status": "LIVE",
                "start_time": (datetime.datetime.now() - datetime.timedelta(hours=1)).isoformat(),
                "last_update": datetime.datetime.now().isoformat()
            }
        ]
        
        # Create NBA live games (NBA playoffs should be happening in April)
        nba_games = [
            {
                "id": "nba_game_1_2025-04-19",
                "sport": "NBA",
                "league": "NBA",
                "home_team": "Los Angeles Lakers",
                "away_team": "Golden State Warriors",
                "home_score": 82,
                "away_score": 75,
                "period": "Q3",
                "time_remaining": "4:35",
                "status": "LIVE",
                "start_time": (datetime.datetime.now() - datetime.timedelta(hours=1, minutes=15)).isoformat(),
                "last_update": datetime.datetime.now().isoformat()
            },
            {
                "id": "nba_game_2_2025-04-19",
                "sport": "NBA",
                "league": "NBA",
                "home_team": "Boston Celtics",
                "away_team": "Philadelphia 76ers",
                "home_score": 105,
                "away_score": 101,
                "period": "Q4",
                "time_remaining": "2:18",
                "status": "LIVE",
                "start_time": (datetime.datetime.now() - datetime.timedelta(hours=2)).isoformat(),
                "last_update": datetime.datetime.now().isoformat()
            }
        ]
        
        # Create MLB upcoming games for today
        mlb_upcoming = [
            {
                "home_team": "Houston Astros",
                "away_team": "Texas Rangers",
                "game_date": (datetime.datetime.now() + datetime.timedelta(hours=4)).isoformat(),
                "home_odds": 1.75,
                "away_odds": 2.15,
                "spread": 1.5,
                "over_under": 8.5,
                "status": "scheduled",
                "sport": "MLB"
            },
            {
                "home_team": "Atlanta Braves",
                "away_team": "New York Mets",
                "game_date": (datetime.datetime.now() + datetime.timedelta(hours=5)).isoformat(),
                "home_odds": 1.65,
                "away_odds": 2.35,
                "spread": 2.5,
                "over_under": 7.5,
                "status": "scheduled",
                "sport": "MLB"
            },
            {
                "home_team": "Toronto Blue Jays",
                "away_team": "Baltimore Orioles",
                "game_date": (datetime.datetime.now() + datetime.timedelta(hours=3)).isoformat(),
                "home_odds": 1.90,
                "away_odds": 1.95,
                "spread": -1.5,
                "over_under": 9.5,
                "status": "scheduled",
                "sport": "MLB"
            }
        ]
        
        # Create NBA upcoming games for today
        nba_upcoming = [
            {
                "home_team": "Miami Heat",
                "away_team": "New York Knicks",
                "game_date": (datetime.datetime.now() + datetime.timedelta(hours=6)).isoformat(),
                "home_odds": 1.62,
                "away_odds": 2.45,
                "spread": 5.5,
                "over_under": 218.5,
                "status": "scheduled",
                "sport": "NBA"
            },
            {
                "home_team": "Denver Nuggets",
                "away_team": "Minnesota Timberwolves",
                "game_date": (datetime.datetime.now() + datetime.timedelta(hours=7)).isoformat(),
                "home_odds": 1.45,
                "away_odds": 2.80,
                "spread": 7.5,
                "over_under": 224.5,
                "status": "scheduled",
                "sport": "NBA"
            }
        ]
        
        # Insert live games
        for game in mlb_games + nba_games:
            insert_query = text("""
                INSERT INTO live_games 
                (id, sport, league, home_team, away_team, home_score, away_score, 
                 period, time_remaining, status, start_time, last_update)
                VALUES (:id, :sport, :league, :home_team, :away_team, :home_score, :away_score,
                        :period, :time_remaining, :status, :start_time, :last_update)
            """)
            conn.execute(insert_query, game)
        
        # Insert upcoming games
        for game in mlb_upcoming + nba_upcoming:
            insert_query = text("""
                INSERT INTO upcoming_games 
                (home_team, away_team, game_date, home_odds, away_odds, spread, over_under, status, sport)
                VALUES (:home_team, :away_team, :game_date, :home_odds, :away_odds, :spread, :over_under, :status, :sport)
            """)
            game_date = datetime.datetime.fromisoformat(game["game_date"])
            conn.execute(insert_query, {
                "home_team": game["home_team"],
                "away_team": game["away_team"],
                "game_date": game_date,
                "home_odds": game["home_odds"],
                "away_odds": game["away_odds"],
                "spread": game["spread"],
                "over_under": game["over_under"],
                "status": game["status"],
                "sport": game["sport"]
            })
        
        conn.commit()

def get_live_games():
    """
    Get current live games from ESPN API
    """
    # Fetch live games from all supported sports
    mlb_live, _ = fetch_mlb_games()
    nba_live, _ = fetch_nba_games()
    nhl_live, _ = fetch_nhl_games()
    
    # Combine all live games
    all_live_games = mlb_live + nba_live + nhl_live
    
    # If we found any games, store them in the database
    if all_live_games:
        with engine.connect() as conn:
            # First clear existing live games
            clear_query = text("DELETE FROM live_games WHERE status = 'LIVE'")
            conn.execute(clear_query)
            
            # Insert new live games
            for game in all_live_games:
                insert_query = text("""
                    INSERT INTO live_games 
                    (id, sport, league, home_team, away_team, home_score, away_score, 
                     period, time_remaining, status, start_time, last_update)
                    VALUES (:id, :sport, :league, :home_team, :away_team, :home_score, :away_score,
                            :period, :time_remaining, :status, :start_time, :last_update)
                    ON CONFLICT (id) DO UPDATE SET
                        home_score = EXCLUDED.home_score,
                        away_score = EXCLUDED.away_score,
                        period = EXCLUDED.period,
                        time_remaining = EXCLUDED.time_remaining,
                        status = EXCLUDED.status,
                        last_update = EXCLUDED.last_update
                """)
                
                # Add a last_update field
                game["last_update"] = datetime.datetime.now().isoformat()
                
                # Add a league field if missing
                if "league" not in game:
                    game["league"] = game["sport"]
                
                # Execute the insert
                try:
                    conn.execute(insert_query, game)
                except Exception as e:
                    # Fallback for databases that don't support ON CONFLICT
                    print(f"Error inserting game: {e}")
                    
                    # Try to update first
                    check_query = text("SELECT id FROM live_games WHERE id = :id")
                    existing = conn.execute(check_query, {"id": game["id"]}).fetchone()
                    
                    if existing:
                        # Update existing game
                        update_query = text("""
                            UPDATE live_games 
                            SET home_score = :home_score, away_score = :away_score,
                                period = :period, time_remaining = :time_remaining,
                                status = :status, last_update = :last_update
                            WHERE id = :id
                        """)
                        
                        conn.execute(update_query, {
                            "id": game["id"],
                            "home_score": game["home_score"],
                            "away_score": game["away_score"],
                            "period": game["period"],
                            "time_remaining": game["time_remaining"],
                            "status": game["status"],
                            "last_update": game["last_update"]
                        })
                    else:
                        # Insert new game
                        insert_query = text("""
                            INSERT INTO live_games 
                            (id, sport, league, home_team, away_team, home_score, away_score, 
                             period, time_remaining, status, start_time, last_update)
                            VALUES (:id, :sport, :league, :home_team, :away_team, :home_score, :away_score,
                                    :period, :time_remaining, :status, :start_time, :last_update)
                        """)
                        conn.execute(insert_query, game)
            
            conn.commit()
    
    return all_live_games

def get_upcoming_games(limit=10):
    """
    Get upcoming games from ESPN API
    """
    # Fetch upcoming games from all supported sports
    _, mlb_upcoming = fetch_mlb_games()
    _, nba_upcoming = fetch_nba_games()
    _, nhl_upcoming = fetch_nhl_games()
    
    # Combine all upcoming games and sort by start time
    all_upcoming_games = sorted(
        mlb_upcoming + nba_upcoming + nhl_upcoming,
        key=lambda g: g.get("start_time", "")
    )
    
    # Limit to requested number
    all_upcoming_games = all_upcoming_games[:limit]
    
    # If we found any games, store them in the database
    if all_upcoming_games:
        with engine.connect() as conn:
            # For each game, check if it exists and update or insert
            for game in all_upcoming_games:
                # Check if game already exists in upcoming_games table
                check_query = text("SELECT id FROM upcoming_games WHERE home_team = :home_team AND away_team = :away_team AND game_date > CURRENT_TIMESTAMP")
                existing = conn.execute(check_query, {
                    "home_team": game["home_team"],
                    "away_team": game["away_team"]
                }).fetchone()
                
                if existing:
                    continue  # Skip if already exists
                
                # Calculate odds
                home_odds = game.get("home_odds", 1.91)
                away_odds = game.get("away_odds", 1.91)
                
                # For sports like baseball, we need different spread/over-under ranges
                if game["sport"] == "MLB":
                    spread = random.choice([-2.5, -1.5, -0.5, 0.5, 1.5, 2.5])
                    over_under = random.choice([7.5, 8.5, 9.5, 10.5])
                elif game["sport"] == "NBA":
                    spread = random.choice([-12.5, -9.5, -7.5, -5.5, -3.5, -1.5, 1.5, 3.5, 5.5, 7.5, 9.5, 12.5])
                    over_under = random.choice([210.5, 215.5, 220.5, 225.5, 230.5, 235.5])
                elif game["sport"] == "NHL":
                    spread = random.choice([-2.5, -1.5, -0.5, 0.5, 1.5, 2.5])
                    over_under = random.choice([5.5, 6.5, 7.5])
                else:
                    # Default for other sports
                    spread = random.choice([-7.5, -5.5, -3.5, -1.5, 1.5, 3.5, 5.5, 7.5])
                    over_under = random.choice([43.5, 47.5, 51.5, 55.5])
                
                # Insert new upcoming game
                insert_query = text("""
                    INSERT INTO upcoming_games 
                    (home_team, away_team, game_date, home_odds, away_odds, spread, over_under, status, sport)
                    VALUES (:home_team, :away_team, :game_date, :home_odds, :away_odds, :spread, :over_under, 'scheduled', :sport)
                """)
                
                conn.execute(insert_query, {
                    "home_team": game["home_team"],
                    "away_team": game["away_team"],
                    "game_date": datetime.datetime.fromisoformat(game["start_time"]),
                    "home_odds": home_odds,
                    "away_odds": away_odds,
                    "spread": spread,
                    "over_under": over_under,
                    "sport": game["sport"]
                })
            
            conn.commit()
    
    return all_upcoming_games

if __name__ == "__main__":
    # Initialize the database with real games
    live_games, upcoming_games = get_todays_real_games()
    print(f"Found {len(live_games)} live games and {len(upcoming_games)} upcoming games")