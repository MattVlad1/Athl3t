import pandas as pd
from sqlalchemy import create_engine, text
import os

# Create database engine
DATABASE_URL = os.environ.get('DATABASE_URL')
engine = create_engine(DATABASE_URL)

def update_shares_in_database():
    """
    Update the shares_outstanding for all players in the database to lower per-share prices.
    Maintain the same total_worth but increase shares by 10x.
    """
    try:
        with engine.connect() as conn:
            # Get all players
            players_query = "SELECT id, name, current_price, total_worth, shares_outstanding, tier FROM players"
            players = pd.read_sql(players_query, conn)
            
            # Calculate new shares based on tier
            for index, player in players.iterrows():
                player_id = player['id']
                current_shares = player['shares_outstanding']
                current_price = player['current_price']
                current_total_worth = player['total_worth']
                
                # Determine new share count (10x more than before)
                new_shares = current_shares * 10
                
                # Calculate new price to maintain the same total worth
                new_price = current_total_worth / new_shares
                
                # Update in database
                update_query = text("""
                    UPDATE players 
                    SET shares_outstanding = :new_shares,
                        current_price = :new_price
                    WHERE id = :player_id
                """)
                
                conn.execute(update_query, {
                    "new_shares": new_shares,
                    "new_price": new_price,
                    "player_id": player_id
                })
            
            conn.commit()
            print(f"Successfully updated share counts for {len(players)} players")
    
    except Exception as e:
        print(f"Error updating share counts: {str(e)}")
        return False
        
    return True

if __name__ == "__main__":
    update_shares_in_database()